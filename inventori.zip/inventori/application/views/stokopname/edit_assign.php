<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Assign Stokopname
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('stokopname/assign') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Kembali
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open('', [], ['id_stokopname' => $barang_masuk['id_stokopname'], 'user_id' => $this->session->userdata('login_session')['user']]); ?>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="id_barang_masuk">ID Transaksi Barang Masuk</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('id_stokopname', $barang_masuk['id_stokopname']); ?>" type="text" readonly="readonly" class="form-control">
                        <?= form_error('id_stokopname', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="tanggal_masuk">Tanggal Masuk</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('tgl_stokopname', $barang_masuk['tgl_stokopname']); ?> " name="tgl_stokopname" id="tgl_stokopname" type="text" class="form-control" placeholder="Tanggal Masuk..." readonly="readonly">
                        <?= form_error('tgl_stokopname', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="barang_id">Barang</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <select name="barang_id" id="barang_id" class="custom-select" disabled="true">
                                <option value="" selected disabled>Pilih Barang</option>
                                <?php foreach ($barang as $b) : ?>
                                    <option <?= $barang_masuk['barang_id'] == $b['id_barang'] ? 'selected' : ''; ?> <?= set_select('barang_id', $b['id_barang']) ?> value="<?= $b['id_barang'] ?>"><?= $b['id_barang'] . ' | ' . $b['nama_barang'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            
                        </div>
                        <?= form_error('barang_id', '<small class="text-danger">', '</small>'); ?>
                    </div>

                </div>
                 <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="rak_id">Cabinet</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <select name="rak_id" id="rak_id" class="custom-select" disabled="true">
                                <option value="" selected disabled>Pilih Cabinet</option>
                                <?php foreach ($cabinet as $s) : ?>
                                    <option  <?= $barang_masuk['rak_id'] == $s['rak_id'] ? 'selected' : ''; ?><?= set_select('rak_id', $s['rak_id']) ?> value="<?= $s['rak_id'] ?>"><?= $s['nama_rak'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            
                        </div>
                        <?= form_error('rak_id', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                
                
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="hasil_stokopname">Hasil Stokopname</label>
                    <div class="col-md-5">
                        <div class="input-group">
						   <input value="<?= set_value('hasil_stokopname', $barang_masuk['hasil_stokopname']); ?>" name="hasil_stokopname" id="hasil_stokopname" type="number" class="form-control" readonly="readonly"  placeholder="Jumlah Masuk...">
                            <div class="input-group-append">
                                <span class="input-group-text" id="satuan">Satuan</span>
                            </div>
                        </div>
                        <?= form_error('hasil_stokopname', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
				<div class="row form-group">
                    <label class="col-md-4 text-md-right" for="total_mising">Total Barang Hilang</label>
                    <div class="col-md-5">
                        <div class="input-group">
						   <input value="<?= set_value('total_mising', $barang_masuk['total_mising']); ?>" name="total_mising" id="total_mising" type="number" class="form-control" readonly="readonly"  placeholder="Total Barang Hilang...">
                            <div class="input-group-append">
                                <span class="input-group-text" id="satuan">Satuan</span>
                            </div>
                        </div>
                        <?= form_error('total_mising', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="total_stok">Status Penerimaan Stokopname</label>
                    <div class="col-md-5">
                        <div class="form-check">
                          <input class="form-check-input" type="radio"  value="<?= set_value('flag_assign', '1'); ?>"  name="flag_assign" id="flag_assign" >
                          <label class="form-check-label" for="gridRadios1">
                            Ya
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio"  value="<?= set_value('flag_assign', '0'); ?>" name="flag_assign" id="flag_assign">
                          <label class="form-check-label" for="gridRadios2">
                            Tidak
                          </label>
                        </div>
                    </div>
                </div>
				
                <div class="row form-group">
                    <div class="col offset-md-4">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>