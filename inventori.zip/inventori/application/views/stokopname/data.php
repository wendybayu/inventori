<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    InputStok Opname 
                </h4>
            </div>
            <div class="col-auto">
                <a href="#"  id="submitso"  class="btn btn-sm btn-primary btn-icon-split btn_proses_so">
                    <span class="icon">
                       <i class="fas fa-circle-notch"></i>
                    </span>
                    <span class="text">
                        Proses 
                    </span>
                </a>

                             
                <a href="<?= base_url('stokopname/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Input
                    </span>
                </a>
                 
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>No Transaksi</th>
                    <th>Tanggal Stokopname</th>
                    <th>Nama Cabinet</th>
                    <th>Nama Barang</th>
                    <th>Jumlah Sistem</th>
                    <th>Jumlah Fisik</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if ($barangmasuk) :
                    foreach ($barangmasuk as $bm) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $bm['id_stokopname']; ?></td>
                            <td><?= $bm['tgl_stokopname']; ?></td>
                            <td><?= $bm['nama_rak']; ?></td>
                            <td><?= $bm['nama_barang']; ?></td>
                            <td><?= $bm['stok'] . ' ' . $bm['nama_satuan']; ?></td>
                            <td><?= $bm['hasil_stokopname'] . ' ' . $bm['nama_satuan']; ?></td>
                            <td>
                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('stokopname/delete/') . $bm['id_stokopname'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            Data Kosong
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>