<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Tambah Rak
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('rak') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Kembali
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open(); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="nama_supplier">Nama Rak</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1"><i class="fas fa-toolbox"></i></span>
                            </div>
                            <input value="<?= set_value('nama_rak'); ?>" name="nama_rak" id="nama_rak" type="text" class="form-control" placeholder="Nama Rak...">
                        </div>
                        <?= form_error('nama_rak', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        
                </div>

                  <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="alamat">Kapasitas Tersedia</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1"><i class="fas fa-box-open"></i></span>
                            </div>
                            <input value="<?= set_value('capacity_avaliable'); ?>" name="capacity_avaliable" id="capacity_avaliable" type="text" class="form-control" placeholder="Kapasitas Tersedia...">
                        </div>
                        <?= form_error('capacity_avaliable', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                
                    
                </div>
               
                    <div class="col-md-9 offset-md-3">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>