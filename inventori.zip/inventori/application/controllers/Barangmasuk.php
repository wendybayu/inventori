<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barangmasuk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->model('Riwayat_model', 'riwayatmdodel');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Barang Masuk";
       
        $data['barangmasuk'] = $this->admin->getBarangMasuk();
        $data['role']= $this->session->userdata('login_session')['role'];
        $this->template->load('templates/dashboard', 'barang_masuk/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required|trim');
        $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
                
        $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        $input = $this->input->post('rak_id', true);
        $input = $this->input->post('rak_id', true);
        $kuota = $this->admin->get('rak', ['rak_id' => $input])['capacity_used'];
        $kuota_valid = (int)$kuota ;
        //var_dump($kuota_valid);
        $this->form_validation->set_rules('jumlah_masuk', 'Jumlah Masuk', 'required|trim|numeric|less_than['.$kuota_valid.']');
    }

     private function _validasi_terimabarang()
    {
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required|trim');
        $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
                
        $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        $input = $this->input->post('rak_id', true);
        $kuota = $this->admin->get('rak', ['rak_id' => $input])['capacity_avaliable'];
        $kuota_valid = $kuota + 1;
       // $this->form_validation->set_rules('jumlah_masuk', 'Jumlah Masuk', 'required|trim|numeric|greater_than[0]|');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Barang Masuk";
            $data['supplier'] = $this->admin->get('supplier');
            $data['barang'] = $this->admin->get('barang');
            $data['cabinet'] = $this->admin->get('rak');

            $data['role']= $this->session->userdata('login_session')['role'];
            // Mendapatkan dan men-generate kode transaksi barang masuk
            $kode = 'T-BM-' . date('ymd');
            $kode_terakhir = $this->admin->getMax('barang_masuk', 'id_barang_masuk', $kode);
            $kode_tambah = substr($kode_terakhir, -5, 5);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 5, '0', STR_PAD_LEFT);
            $data['id_barang_masuk'] = $kode . $number;

            $this->template->load('templates/dashboard', 'barang_masuk/add', $data);
        } else {
            
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('barang_masuk', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('barangmasuk');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('barangmasuk/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('barang_masuk', 'id_barang_masuk', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('barangmasuk');
    }

    public function riwayat()
    {
        $data['title'] = "Barang Masuk";
        $data['barangmasuk'] = $this->admin->getriwayatBarangMasuk();
        $data['role']= $this->session->userdata('login_session')['role'];
        $this->template->load('templates/dashboard', 'barang_masuk/riwayat', $data);
    }

    public function terima()
    {
        $data['title'] = "Barang Masuk";
        $data['role']= $this->session->userdata('login_session')['role'];
        $data['barangmasuk'] = $this->admin->getTerimaBarangMasuk();
        $this->template->load('templates/dashboard', 'barang_masuk/terima', $data);
    }

     public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi_terimabarang();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Barang Masuk";
            $data['role']= $this->session->userdata('login_session')['role'];
            $data['supplier'] = $this->admin->get('supplier');
            $data['barang'] = $this->admin->get('barang');
            $data['barang_masuk'] = $this->admin->get('barang_masuk', ['id_barang_masuk' => $id]);
            $data['cabinet'] = $this->admin->get('rak');
            $this->template->load('templates/dashboard', 'barang_masuk/edit', $data);
        } else {
            $input = array(
                'flag_receipt'=>$this->input->post('flag_receipt'),
                'receipt_by'=>$this->session->userdata('login_session')['user']
            );
            //$this->input->post(null, true);
            $update = $this->admin->update('barang_masuk', 'id_barang_masuk', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('barangmasuk/terima');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('barangmasuk/edit/' . $id);
            }
        }
    }

    public function submit_all(){
        $user=$this->session->userdata('login_session')['user'];
        $pilih='BM';
        $table='barang_masuk';
        
        $hasilCekdata = $this->admin->cekDataBeforeSubmit($user,$table);
        if($hasilCekdata<>true){
            echo 'null';

        }else{
            $this->admin->submit($user,$pilih);
            echo 'masuk';   
        }

        
    }

   
}
