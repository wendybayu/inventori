<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('transaksi', 'Transaksi', 'required|in_list[barang_masuk,barang_keluar,stokopname]');
        $this->form_validation->set_rules('tanggal', 'Periode Tanggal', 'required');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Laporan Transaksi";
             $data['role']= $this->session->userdata('login_session')['role'];
            $this->template->load('templates/dashboard', 'laporan/form', $data);
        } else {
            $input = $this->input->post(null, true);
            $table = $input['transaksi'];
            $tanggal = $input['tanggal'];
            $pecah = explode(' - ', $tanggal);
            $mulai = date('Y-m-d', strtotime($pecah[0]));
            $akhir = date('Y-m-d', strtotime(end($pecah)));

            $query = '';
            if ($table == 'barang_masuk') {
                $query = $this->admin->getLapBarangMasuk(null, null, ['mulai' => $mulai, 'akhir' => $akhir]);
                $query2 ='';
                 $query3="";
                  $query4="";
            } else if ($table == 'stokopname') {
                $query = $this->admin->getLaporanSo(null, null, ['mulai' => $mulai, 'akhir' => $akhir]); 
                $query2 = $this->admin->getLaporanNilaiSo(null, null, ['mulai' => $mulai, 'akhir' => $akhir]);
                $query3 = $this->admin->getLaporanNilaistok(null, null, ['mulai' => $mulai, 'akhir' => $akhir]); 
                $query4 = $this->admin->getLaporanNilaiselisih(null, null, ['mulai' => $mulai, 'akhir' => $akhir]); 

            } else {
                $query = $this->admin->getLapBarangKeluar(null, null, ['mulai' => $mulai, 'akhir' => $akhir]);
                $query2 ='';
                 $query3="";
                  $query4="";
            }

            $this->_cetak($query, $table, $tanggal,$query2,$query3,$query4);
        }
    }

    private function _cetak($data, $table_, $tanggal, $query2,$query3,$query4)
    {
        $this->load->library('CustomPDF');
        // $table = (case when $table_ == 'barang_masuk' then 'Barang Masuk'
        //     when $table_ == 'barang_keluar' then 'Barang Keluar' else 'Stok Opname' end
        // );

        if ($table_ == 'barang_masuk'):
            $table ='Barang Masuk';
        elseif ($table_ == 'stokopname'):
           $table ='Stok Opname';
         else  :
            $table ='Barang Keluar';
        endif;    
        //$table = $table_ == 'stokopname' ? 'Barang Masuk' : 'Barang Keluar';

        $pdf = new FPDF();
        $pdf->AddPage('L', 'Letter');
        $pdf->SetFont('Times', 'B', 16);
        $pdf->Cell(190, 7, 'Laporan ' . $table, 0, 1, 'C');
        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(190, 4, 'Tanggal : ' . $tanggal, 0, 1, 'C');
        $pdf->Ln(10);

        $pdf->SetFont('Arial', 'B', 10);

        if ($table_ == 'barang_masuk') :
            $pdf->Cell(10, 7, 'No.', 1, 0, 'C');
            $pdf->Cell(35, 7, 'Tgl Masuk', 1, 0, 'C');
            $pdf->Cell(35, 7, 'ID Transaksi', 1, 0, 'C');
            $pdf->Cell(100, 7, 'Nama Barang', 1, 0, 'C');
            $pdf->Cell(40, 7, 'Supplier', 1, 0, 'C');
            $pdf->Cell(30, 7, 'Jumlah Masuk', 1, 0, 'C');
            $pdf->Ln();

            $no = 1;
            foreach ($data as $d) {
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(10, 7, $no++ . '.', 1, 0, 'C');
               // $pdf->Cell(25, 7, $d['tanggal_masuk'], 1, 0, 'C');
                 $pdf->Cell(35, 7, date_format(new DateTime($d['tanggal_masuk']),"d F Y")
                    , 1, 0, 'C');
                $pdf->Cell(35, 7, $d['id_barang_masuk'], 1, 0, 'C');
                $pdf->Cell(100, 7, $d['nama_barang'], 1, 0, 'L');
                $pdf->Cell(40, 7, $d['nama_supplier'], 1, 0, 'L');
                $pdf->Cell(30, 7, $d['jumlah_masuk'] . ' ' . $d['nama_satuan'], 1, 0, 'C');
                $pdf->Ln();

            } 
        endif;


            if ($table_ == 'stokopname') :

                 $pdf->Cell(10, 7, 'No.', 1, 0, 'C');
            $pdf->Cell(35, 7, 'Tgl SO', 1, 0, 'C');
            $pdf->Cell(100, 7, 'Nama Barang', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Qty Stock', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Qty SO', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Qty Selisih', 1, 0, 'C');
            $pdf->Cell(45, 7, 'Nilai (Rp.)', 1, 0, 'C');
            $pdf->Ln();

            $no = 1;
            foreach ($data as $d) {
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(10, 7, $no++ . '.', 1, 0, 'C');
                $pdf->Cell(35, 7, date_format(new DateTime($d['tgl_stokopname']),"d F Y")
                    , 1, 0, 'C');
                $pdf->Cell(100, 7, $d['nama_barang'], 1, 0, 'C');
                $pdf->Cell(25, 7, $d['stok'], 1, 0, 'C');
                $pdf->Cell(25, 7, $d['hasil_stokopname'], 1, 0, 'C');
                $pdf->Cell(25, 7, $d['hasil_stokopname'] - $d['stok'], 1, 0, 'C');
                 $pdf->Cell(45, 7, number_format($d['harga'],2,".",","), 1, 0, 'C');
                $pdf->Ln();

            } 

           

            foreach ($query3 as $c) {
             $pdf->Cell(10, 7, '', 1, 0, 'C');
            $pdf->Cell(35, 7, '', 1, 0, 'C');
            $pdf->Cell(100, 7, '', 1, 0, 'C');
            $pdf->Cell(25, 7, '', 1, 0, 'C');
           $pdf->Cell(25, 7, '', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Tot Nilai Stok', 1, 0, 'C');
            $pdf->Cell(45, 7,number_format($c['tot_nilai_stok'],2,".",",") , 1, 0, 'C');

            $pdf->Ln();
            } 
			
			     foreach ($query2 as $q) {

            $pdf->Cell(10, 7, '', 1, 0, 'C');
            $pdf->Cell(35, 7, '', 1, 0, 'C');
            $pdf->Cell(100, 7, '', 1, 0, 'C');
            $pdf->Cell(25, 7, '', 1, 0, 'C');
           $pdf->Cell(25, 7, '', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Tot Nilai SO', 1, 0, 'C');
            $pdf->Cell(45, 7,number_format($q['tot_nilai_so'] ,2,".",",")  , 1, 0, 'C');
            $pdf->Ln();
            } 

            foreach ($query4 as $d) {

            $pdf->Cell(10, 7, '', 1, 0, 'C');
            $pdf->Cell(35, 7, '', 1, 0, 'C');
            $pdf->Cell(100, 7, '', 1, 0, 'C');
            $pdf->Cell(25, 7, '', 1, 0, 'C');
           $pdf->Cell(25, 7, '', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Selisih', 1, 0, 'C');
            $pdf->Cell(45, 7, number_format($d['selisih_stok'],2,".",","), 1, 0, 'C');
            $pdf->Ln();
              } 
        endif;

        if ($table_ == 'barang_keluar') :
            
            $pdf->Cell(10, 7, 'No.', 1, 0, 'C');
            $pdf->Cell(35, 7, 'Tgl Keluar', 1, 0, 'C');
            $pdf->Cell(35, 7, 'ID Transaksi', 1, 0, 'C');
            $pdf->Cell(100, 7, 'Nama Barang', 1, 0, 'C');
            $pdf->Cell(30, 7, 'Jumlah Keluar', 1, 0, 'C');
            $pdf->Ln();

            $no = 1;
            foreach ($data as $d) {
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(10, 7, $no++ . '.', 1, 0, 'C');
                //$pdf->Cell(25, 7, $d['tanggal_keluar'], 1, 0, 'C');
                $pdf->Cell(35, 7, date_format(new DateTime($d['tanggal_keluar']),"d F Y")
                    , 1, 0, 'C');
                $pdf->Cell(35, 7, $d['id_barang_keluar'], 1, 0, 'C');
                $pdf->Cell(100, 7, $d['nama_barang'], 1, 0, 'L');
                $pdf->Cell(30, 7, $d['jumlah_keluar'] . ' ' . $d['nama_satuan'], 1, 0, 'C');
                $pdf->Ln();
            }
        endif;

        $file_name = $table . ' ' . $tanggal;
        $pdf->Output('I', $file_name);
    }
}
