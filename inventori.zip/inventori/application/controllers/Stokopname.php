<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stokopname extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Stokopname";
       $data['role']= $this->session->userdata('login_session')['role'];
        $data['barangmasuk'] = $this->admin->getStokopname();
        $this->template->load('stokopname/dashboard_so', 'stokopname/data', $data);
    }

    public function riwayat()
    {
        $data['title'] = "Stok Opname";
        $data['role']= $this->session->userdata('login_session')['role'];
        $data['barangmasuk'] = $this->admin->getriwayatStokopname();
        $this->template->load('templates/dashboard', 'stokopname/riwayat', $data);
    }
    public function assign()
    {
            $data['title'] = "Stok Opname";
            $data['role']= $this->session->userdata('login_session')['role'];
            $data['barangmasuk'] = $this->admin->getassignStokopname();
            $this->template->load('templates/dashboard', 'stokopname/assign', $data);
        }
    public function approval()
    {
            $data['title'] = "Stok Opname";
            $data['role']= $this->session->userdata('login_session')['role'];
            $data['barangmasuk'] = $this->admin->getapprovalStokopname();
            $this->template->load('templates/dashboard', 'stokopname/approval', $data);
        }
    private function _validasi()
    {
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required|trim');
        $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
                
        $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        $input = $this->input->post('rak_id', true);
        $kuota = $this->admin->get('rak', ['rak_id' => $input])['capacity_avaliable'];
        $kuota_valid = $kuota + 1;
        $this->form_validation->set_rules('jumlah_masuk', 'Jumlah Masuk', 'required|trim|numeric|greater_than[0]|greater_than[{$kuota_valid}]',[
                'greater_than' => "Jumlah Masuk tidak boleh lebih dari {$kuota_valid}"
            ]);
    }

     private function _validasi_terimabarang()
    {
        $this->form_validation->set_rules('tgl_stokopname', 'Tanggal Stokopname', 'required');
                    
       // $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        //$this->form_validation->set_rules('rak_id', 'Cabinet', 'required');
       // $this->form_validation->set_rules('jumlah_masuk', 'Jumlah Masuk', 'required|trim|numeric|greater_than[0]|');
    }

    public function add()
    {
        $this->_validasi_terimabarang();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Stok Opname";
           $data['role']= $this->session->userdata('login_session')['role'];
            $data['barang'] = $this->admin->get('barang');
            $data['cabinet'] = $this->admin->get('rak');


            // Mendapatkan dan men-generate kode transaksi barang masuk
            $kode = 'SO-' . date('ymd');
            $kode_terakhir = $this->admin->getMax('stokopname', 'id_stokopname', $kode);
            $kode_tambah = substr($kode_terakhir, -5, 5);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 5, '0', STR_PAD_LEFT);
            $data['id_stokopname'] = $kode . $number;

            $this->template->load('templates/dashboard', 'stokopname/add', $data);
        } else {
            
            $input = array(
                'id_stokopname'=>$this->input->post('id_stokopname'),
                'user_id'=>$this->session->userdata('login_session')['user'],
                'tgl_stokopname'=>$this->input->post('tgl_stokopname'),
                'rak_id'=>$this->input->post('rak_id'),
                'barang_id'=>$this->input->post('barang_id'),
                'hasil_stokopname'=>$this->input->post('hasil_stokopname')
            );
            $insert = $this->admin->insert('stokopname', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('stokopname');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('stokopname/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('stokopname', 'id_stokopname', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('stokopname');
    }

    

    public function terima()
    {
        $data['title'] = "Stok Opname";
         $data['role']= $this->session->userdata('login_session')['role'];
        $data['barangmasuk'] = $this->admin->getTerimaBarangMasuk();
        $this->template->load('templates/dashboard', 'barang_masuk/terima', $data);
    }

     public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi_terimabarang();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Stok Opname";
             $data['role']= $this->session->userdata('login_session')['role'];
            $data['supplier'] = $this->admin->get('supplier');
            $data['barang'] = $this->admin->get('barang');
            $data['barang_masuk'] = $this->admin->get('barang_masuk', ['id_barang_masuk' => $id]);
            $data['cabinet'] = $this->admin->get('rak');
            $this->template->load('templates/dashboard', 'barang_masuk/edit', $data);
        } else {
            $input = array(
                'flag_receipt'=>$this->input->post('flag_receipt'),
                'receipt_by'=>$this->session->userdata('login_session')['user']
            );
            //$this->input->post(null, true);
            $update = $this->admin->update('barang_masuk', 'id_barang_masuk', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('barangmasuk/terima');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('barangmasuk/edit/' . $id);
            }
        }
    }

     public function editAssign($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi_terimabarang();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Barang Masuk";
             $data['role']= $this->session->userdata('login_session')['role'];
            $data['supplier'] = $this->admin->get('supplier');
            $data['barang'] = $this->admin->get('barang');
            $data['barang_masuk'] = $this->admin->get('stokopname', ['id_stokopname' => $id]);
            $data['cabinet'] = $this->admin->get('rak');
            $this->template->load('templates/dashboard', 'stokopname/edit_assign', $data);
        } else {
            
            if ( $this->input->post('flag_assign')== '1' ) {
                $vflag_submit = '1' ;
            } else{
                 $vflag_submit = '0';
                 }

            $input = array(
                'flag_assign'=>$this->input->post('flag_assign'),
                'date_assign'=>date('Y-m-d'),
                'flag_submit'=> $vflag_submit
                // 'receipt_by'=>$this->session->userdata('login_session')['user']
            );
            //$this->input->post(null, true);
            $update = $this->admin->update('stokopname', 'id_stokopname', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('stokopname/assign');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('stokopname/editAssign/' . $id);
            }
        }
    }

    public function editApproval($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi_terimabarang();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Stok Opname";
             $data['role']= $this->session->userdata('login_session')['role'];
            $data['supplier'] = $this->admin->get('supplier');
            $data['barang'] = $this->admin->get('barang');
            $data['barang_masuk'] = $this->admin->get('stokopname', ['id_stokopname' => $id]);
            $data['cabinet'] = $this->admin->get('rak');
            $this->template->load('templates/dashboard', 'stokopname/edit_approval', $data);
        } else {
            
            if ( $this->input->post('flag_assign')== '1' ) {
                $vflag_submit = '1' ;
            } else{
                 $vflag_submit = '0';
                 }

            $input = array(
                'flag_approval'=>$this->input->post('flag_approval'),
                'date_approval'=>date('Y-m-d'),
                'approved_by'=> $this->session->userdata('login_session')['user']
            );
            //$this->input->post(null, true);
            $update = $this->admin->update('stokopname', 'id_stokopname', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('stokopname/assign');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('stokopname/edit_approval/' . $id);
            }
        }
    }

    public function submit_all(){
        $user=$this->session->userdata('login_session')['user'];
        $pilih='SO';
        $table='stokopname';
        
        $hasilCekdata = $this->admin->cekDataBeforeSubmit($user,$table);
        if($hasilCekdata<>true){
            echo 'null';

        }else{
            $this->admin->submit($user,$pilih);
            echo 'masuk';   
        }

        
    }
}
