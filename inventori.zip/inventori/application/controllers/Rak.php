<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rak extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Cabinet";
        $data['supplier'] = $this->admin->get('rak');
        $data['role']= $this->session->userdata('login_session')['role'];
        $this->template->load('templates/dashboard', 'rak/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_rak', 'Cabinet Name', 'required|trim');
         $this->form_validation->set_rules('capacity_avaliable', 'capacity_avaliable', 'required|trim|numeric');
        
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Cabinet";
            $data['role']= $this->session->userdata('login_session')['role'];
            $this->template->load('templates/dashboard', 'rak/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $save = $this->admin->insert('rak', $input);
            if ($save) {
                set_pesan('data berhasil disimpan.');
                redirect('rak');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('rak/add');
            }
        }
    }


    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Cabinet";
            $data['role']= $this->session->userdata('login_session')['role'];
            $data['cabinet'] = $this->admin->get('rak', ['rak_id' => $id]);
            $this->template->load('templates/dashboard', 'rak/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('rak', 'rak_id', $id, $input);

            if ($update) {
                set_pesan('data berhasil diedit.');
                redirect('rak');
            } else {
                set_pesan('data gagal diedit.');
                redirect('rak/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('supplier', 'id_supplier', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('supplier');
    }
}
