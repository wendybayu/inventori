<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    

    public function get($table, $data = null, $where = null)
    {
        if ($data != null) {
            return $this->db->get_where($table, $data)->row_array();
        } else {
            return $this->db->get_where($table, $where)->result_array();
        }
    }

    public function update($table, $pk, $id, $data)
    {
        $this->db->where($pk, $id);
        return $this->db->update($table, $data);
    }

    public function insert($table, $data, $batch = false)
    {
        return $batch ? $this->db->insert_batch($table, $data) : $this->db->insert($table, $data);
    }

    public function delete($table, $pk, $id)
    {
        return $this->db->delete($table, [$pk => $id]);
    }

    public function getUsers($id)
    {
        /**
         * ID disini adalah untuk data yang tidak ingin ditampilkan. 
         * Maksud saya disini adalah 
         * tidak ingin menampilkan data user yang digunakan, 
         * pada managemen data user
         */
        $this->db->where('id_user !=', $id);
        return $this->db->get('user')->result_array();
    }

    public function getBarang()
    {
        $this->db->join('jenis j', 'b.jenis_id = j.id_jenis');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->order_by('id_barang');
        return $this->db->get('barang b')->result_array();
    }

    public function getDashboardBarangMasuk($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('supplier sp', 'bm.supplier_id = sp.id_supplier');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',1);
        $this->db->where(' flag_receipt',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
            $this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_masuk', 'DESC');
        return $this->db->get('barang_masuk bm')->result_array();
    }

    public function getBarangMasuk($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('supplier sp', 'bm.supplier_id = sp.id_supplier');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',0);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
            $this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_masuk', 'DESC');
        return $this->db->get('barang_masuk bm')->result_array();
    }
	
	public function getLapBarangMasuk($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('supplier sp', 'bm.supplier_id = sp.id_supplier');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',1);
		$this->db->where('flag_receipt',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
            $this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_masuk', 'DESC');
        return $this->db->get('barang_masuk bm')->result_array();
    }

     public function getLaporanSo($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('barang u', 'bm.barang_id = u.id_barang');
        $this->db->join('rak sp', 'bm.rak_id = sp.rak_id');
        $this->db->where('flag_submit',1);
        $this->db->where('flag_assign',1);
        $this->db->where('flag_approval',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_stokopname', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

    public function getLaporanNilaiSo($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('sum(hasil_stokopname* harga) as tot_nilai_so');
        $this->db->join('barang u', 'bm.barang_id = u.id_barang');
        $this->db->join('rak sp', 'bm.rak_id = sp.rak_id');
        $this->db->where('flag_submit',1);
        $this->db->where('flag_assign',1);
        $this->db->where('flag_approval',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_stokopname', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

     public function getLaporanNilaistok($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('sum(stok  * harga) as tot_nilai_stok');
        $this->db->join('barang u', 'bm.barang_id = u.id_barang');
        $this->db->join('rak sp', 'bm.rak_id = sp.rak_id');
        $this->db->where('flag_submit',1);
        $this->db->where('flag_assign',1);
        $this->db->where('flag_approval',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_stokopname', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

    public function getLaporanNilaiselisih($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('(sum(hasil_stokopname* harga) - (sum(stok  * harga))) as selisih_stok');
        $this->db->join('barang u', 'bm.barang_id = u.id_barang');
        $this->db->join('rak sp', 'bm.rak_id = sp.rak_id');
        $this->db->where('flag_submit',1);
        $this->db->where('flag_assign',1);
        $this->db->where('flag_approval',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_stokopname', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

    public function getriwayatBarangMasuk($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('rak ri', 'ri.rak_id = bm.rak_id');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
            $this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_masuk', 'DESC');
        return $this->db->get('barang_masuk bm')->result_array();
    }

    public function getStokopname($limit = null, $id_barang = null, $range = null)
    
    {
        $user = $this->session->userdata('login_session')['user'];
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('rak c', 'c.rak_id = bm.rak_id');
        $this->db->join('satuan s', 's.id_satuan = b.satuan_id');
      
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('barang_id', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }
        $this->db->where('flag_submit',0);
        $this->db->where('user_id',$user);
        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }
    public function getriwayatStokopname($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('rak c', 'c.rak_id = bm.rak_id');
        $this->db->join('satuan s', 's.id_satuan = b.satuan_id');
      
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('barang_id', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }
        $this->db->where('flag_submit',1);
        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

    public function getapprovalStokopname($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('rak c', 'c.rak_id = bm.rak_id');
        $this->db->join('satuan s', 's.id_satuan = b.satuan_id');
      
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('barang_id', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }
        $this->db->where('flag_submit',1);
        $this->db->where('flag_assign',1);
        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

    public function getassignStokopname($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('rak c', 'c.rak_id = bm.rak_id');
        $this->db->join('satuan s', 's.id_satuan = b.satuan_id');
      
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('barang_id', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tgl_stokopname' . ' >=', $range['mulai']);
            $this->db->where('tgl_stokopname' . ' <=', $range['akhir']);
        }
        $this->db->where('flag_submit',1);
         $this->db->where('flag_assign',0);
        $this->db->order_by('id_stokopname', 'DESC');
        return $this->db->get('stokopname bm')->result_array();
    }

    public function getTerimaBarangMasuk($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('rak c', 'c.rak_id = bm.rak_id');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',1);
        $this->db->where('flag_receipt',0);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
            $this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_masuk', 'DESC');
        return $this->db->get('barang_masuk bm')->result_array();
    }

    public function getTerimaBarangKeluar($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('rak c', 'c.rak_id = bm.rak_id');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',1);
        $this->db->where('flag_receipt',0);
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
            $this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_keluar', 'DESC');
        return $this->db->get('barang_keluar bm')->result_array();
    }

    public function getBarangKeluar($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bk.user_id = u.id_user');
        $this->db->join('barang b', 'bk.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',0);
        if ($limit != null) {
            $this->db->limit($limit);
        }
        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }
        if ($range != null) {
            $this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
            $this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
        }
        $this->db->order_by('id_barang_keluar', 'DESC');
        return $this->db->get('barang_keluar bk')->result_array();
    }
	
	public function getLapBarangKeluar($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bk.user_id = u.id_user');
        $this->db->join('barang b', 'bk.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',1);
		$this->db->where('flag_receipt',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }
        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }
        if ($range != null) {
            $this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
            $this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
        }
        $this->db->order_by('id_barang_keluar', 'DESC');
        return $this->db->get('barang_keluar bk')->result_array();
    }
	
    public function getDashboardBarangKeluar($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bk.user_id = u.id_user');
        $this->db->join('barang b', 'bk.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->where('flag_submit',1);
         $this->db->where('flag_receipt',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }
        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }
        if ($range != null) {
            $this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
            $this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
        }
        $this->db->order_by('id_barang_keluar', 'DESC');
        return $this->db->get('barang_keluar bk')->result_array();
    }
    public function getriwayatBarangKeluar($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bk.user_id = u.id_user');
        $this->db->join('barang b', 'bk.barang_id = b.id_barang');
        $this->db->join('satuan s', 'b.satuan_id = s.id_satuan');
        $this->db->join('rak c', 'c.rak_id = bk.rak_id');
        $this->db->where('flag_submit',1);
        if ($limit != null) {
            $this->db->limit($limit);
        }
        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }
        if ($range != null) {
            $this->db->where('tanggal_keluar' . ' >=', $range['mulai']);
            $this->db->where('tanggal_keluar' . ' <=', $range['akhir']);
        }
        $this->db->order_by('id_barang_keluar', 'DESC');
        return $this->db->get('barang_keluar bk')->result_array();
    }

    public function getMax($table, $field, $kode = null)
    {
        $this->db->select_max($field);
        if ($kode != null) {
            $this->db->like($field, $kode, 'after');
        }
        return $this->db->get($table)->row_array()[$field];
    }

    public function count($table)
    {
        return $this->db->count_all($table);
    }

    public function sum($table, $field)
    {
        $this->db->select_sum($field);
        return $this->db->get($table)->row_array()[$field];
    }

    public function min($table, $field, $min)
    {
        $field = $field . ' <=';
        $this->db->where($field, $min);
        return $this->db->get($table)->result_array();
    }

    public function chartBarangMasuk($bulan)
    {
        $like = 'T-BM-' . date('y') . $bulan;
        $this->db->like('id_barang_masuk', $like, 'after');
        return count($this->db->get('barang_masuk')->result_array());
    }

    public function chartBarangKeluar($bulan)
    {
        $like = 'T-BK-' . date('y') . $bulan;
        $this->db->like('id_barang_keluar', $like, 'after');
        return count($this->db->get('barang_keluar')->result_array());
    }

    public function laporan($table, $mulai, $akhir)
    {
        $tgl = $table == 'barang_masuk' ? 'tanggal_masuk' : 'tanggal_keluar';
        $this->db->where($tgl . ' >=', $mulai);
        $this->db->where($tgl . ' <=', $akhir);
        return $this->db->get($table)->result_array();
    }

    public function cekStok($id)
    {
        $this->db->join('satuan s', 'b.satuan_id=s.id_satuan');
        return $this->db->get_where('barang b', ['id_barang' => $id])->row_array();
    }

    public function cekKuota($id)
    {
     
     $this->db->where('rak_id', $id)  ; 
    return  $this->db->get('rak')->row_array();
    }

   public function submit($user,$pilih){
        $sql ="call submit_all(?,?)";
        $param = array(
            'user'=>$user,
            'pilih'=>$pilih
            
        );
        $this->db->query($sql,$param);
    }

    public function cekDataBeforeSubmit($user,$table){
        
                   
           if ($table =='stokopname'){
            $this->db->where('flag_submit',0);
            $this->db->where('user_id',$user); 

           }elseif ($table =='barang_masuk') {
            $this->db->where('flag_submit',0);
            $this->db->where('flag_receipt',0);
            $this->db->where('user_id',$user); 
           }else{
            $this->db->where('flag_submit',0);
            $this->db->where('user_id',$user);  
           }
          
          
            $query=$this->db->get($table);
            
        if($query->num_rows()>0){
            
            return true;
        }
        else{
            return false;
        }

    }
}
